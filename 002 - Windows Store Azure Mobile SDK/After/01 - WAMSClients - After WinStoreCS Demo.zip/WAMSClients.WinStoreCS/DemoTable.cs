﻿namespace WAMSClients.WinStoreCS
{
  public class DemoTable
  {
    public string Id { get; set; }

    public string FirstName { get; set; }

    public string LastName { get; set; }
  }
}